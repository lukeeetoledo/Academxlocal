<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_verify.css" />
    <title>Document</title>
</head>

<body>
    <div class="card">
        <form>
                <a href="verify.php?token=Student" id="back">Back</a>
                <span style = "float:right"> 2 of 2 </span>
        <br>
            <h3> [Student] Please attach the required document: </h3>
            <button type="button" id="next">Submit</button>
        </form>
    </div>
</body>

</html>