<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "academx_db";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");

$base_url="http://localhost/ElectiveProject/AcadeMx/";
$my_email = 'testacademx@gmail.com';
?>